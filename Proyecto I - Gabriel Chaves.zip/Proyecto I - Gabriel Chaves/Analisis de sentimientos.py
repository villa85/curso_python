import  re
from mis_funciones import funciones as f

twet = open("data\\"+'sentweets_esp.txt', encoding="utf8")
texto = twet.read()

stop = open("data\\"+'stopwords_español.txt', encoding="utf8")
stopW = stop.read().split("\n")

sentpos = open("data\\"+'positive_lex.txt', encoding="utf8")
sentpos = sentpos.read()
listapos = re.split("\n|\s",sentpos)[0:-1]

sentneg = open("data\\"+'negative_lex.txt', encoding="utf8")
sentneg = sentneg.read()
listaneg = re.split("\n|\s",sentneg)[0:-1]

print(f.sent(texto, stopW,listapos,listaneg))
