
from mis_funciones import menu as m

archivo = open("data\\"+'articulo.txt', encoding="utf8")
articulo = archivo.read()

stop = open("data\\"+'stopwords_español.txt', encoding="utf8")
stopW = stop.read().split("\n")




m.menu(articulo, stopW)
